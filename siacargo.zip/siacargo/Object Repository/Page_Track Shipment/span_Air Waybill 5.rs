<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Air Waybill 5</name>
   <tag></tag>
   <elementGuidId>c6c04ca7-d269-4505-b111-214779a688d8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='queryArea']/div[2]/div/div[5]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.awb-row-5 > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9bd26916-4114-485e-a582-5923c1cc86a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Air Waybill 5</value>
      <webElementGuid>9030a4f4-4c48-4ead-a562-fbec15498415</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;queryArea&quot;)/div[@class=&quot;row input-area&quot;]/div[@class=&quot;col-xs-12 col-sm-6&quot;]/div[@class=&quot;awb-row-5&quot;]/span[1]</value>
      <webElementGuid>f860dd25-12a4-4054-aa91-5f4228e1d286</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='queryArea']/div[2]/div/div[5]/span</value>
      <webElementGuid>389987ee-a658-4ee5-88ee-4b9d224e62ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[4]/following::span[3]</value>
      <webElementGuid>7d5666b3-bb45-4a37-b8c5-61241ef21a0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Air Waybill 4'])[1]/following::span[4]</value>
      <webElementGuid>d03795c8-2659-43e3-a6d0-e7d8f11efe6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[5]/preceding::span[1]</value>
      <webElementGuid>7969d662-4691-4d35-ab91-c4acbc20e08b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Optional:'])[1]/preceding::span[5]</value>
      <webElementGuid>0790b402-9093-40e7-a66d-58cb708b6779</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Air Waybill 5']/parent::*</value>
      <webElementGuid>bef69734-b666-4a14-a003-2c7f01718e03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/span</value>
      <webElementGuid>65a56df6-f7e2-4648-8979-ecc166015e6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Air Waybill 5' or . = 'Air Waybill 5')]</value>
      <webElementGuid>a67c29e8-4ed5-4648-b8a3-d4147d65a65b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
