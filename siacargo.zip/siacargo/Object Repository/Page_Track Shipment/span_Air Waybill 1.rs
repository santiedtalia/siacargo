<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Air Waybill 1</name>
   <tag></tag>
   <elementGuidId>34316a70-8de4-49d7-9b72-3114baa86226</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='queryArea']/div[2]/div/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.awb-row > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8068c4d2-a1e0-465a-a26b-d80d1b4dedbe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Air Waybill 1</value>
      <webElementGuid>037938d9-8ea1-4bd7-87d2-732a978332cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;queryArea&quot;)/div[@class=&quot;row input-area&quot;]/div[@class=&quot;col-xs-12 col-sm-6&quot;]/div[@class=&quot;awb-row&quot;]/span[1]</value>
      <webElementGuid>d12446a9-d6c2-42bd-96e9-3c7b104100f1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='queryArea']/div[2]/div/div/span</value>
      <webElementGuid>5e308154-2166-4e5e-bc2d-f6ef7aaa00ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter the air waybill number(s) of your shipment(s) to view its status.'])[1]/following::span[1]</value>
      <webElementGuid>6666dbae-0ebc-42b7-81d1-97e78defdea5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Track Shipment'])[2]/following::span[1]</value>
      <webElementGuid>a1e39eb8-62b0-4068-bb05-539945b2ff03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[1]/preceding::span[1]</value>
      <webElementGuid>65289c68-34b6-4931-8651-40180f9ff7d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Air Waybill 2'])[1]/preceding::span[4]</value>
      <webElementGuid>6ac1fb4c-7ca0-487f-b2a8-50866b5d1336</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Air Waybill 1']/parent::*</value>
      <webElementGuid>c07fc461-57c9-413b-b9c1-c56bed12dd4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/span</value>
      <webElementGuid>f85dbe81-dbcd-4692-9273-a0d361e2627d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Air Waybill 1' or . = 'Air Waybill 1')]</value>
      <webElementGuid>1a805f70-14c3-4cc1-b238-0a1352c14f78</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
