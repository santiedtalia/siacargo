<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Air Waybill 3</name>
   <tag></tag>
   <elementGuidId>ee7e102b-1190-4273-bbe2-cebe5eb739d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='queryArea']/div[2]/div/div[3]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b5eaaf1e-172a-445b-b899-11ba3bed3751</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Air Waybill 3</value>
      <webElementGuid>3ee345ce-c1cb-4207-9f48-82262fd9456b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;queryArea&quot;)/div[@class=&quot;row input-area&quot;]/div[@class=&quot;col-xs-12 col-sm-6&quot;]/div[@class=&quot;awb-row&quot;]/span[1]</value>
      <webElementGuid>165b8761-5ecf-4280-aa8b-927ded7e25e5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='queryArea']/div[2]/div/div[3]/span</value>
      <webElementGuid>0cb78747-a94f-4e9f-a255-e6bd886d3f8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[2]/following::span[3]</value>
      <webElementGuid>b67a9109-180d-4f08-a2b4-f0e67def7ad8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Air Waybill 2'])[1]/following::span[4]</value>
      <webElementGuid>016cf323-4956-46c7-8895-cba5633501c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[3]/preceding::span[1]</value>
      <webElementGuid>f5dc75c8-3fdd-4c1e-9571-623e017295ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Air Waybill 4'])[1]/preceding::span[4]</value>
      <webElementGuid>26fc11e2-35cd-4148-9298-9c8b136aef21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Air Waybill 3']/parent::*</value>
      <webElementGuid>cb3da673-ca61-430e-9aff-341eab5aeb32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/span</value>
      <webElementGuid>dd071a6b-723a-48c9-bb3e-bb6616a9eec0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Air Waybill 3' or . = 'Air Waybill 3')]</value>
      <webElementGuid>4527e7bc-c71e-45cf-a36a-02acee39b474</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
