<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Air Waybill 2</name>
   <tag></tag>
   <elementGuidId>dc91617f-f01f-4ede-adeb-c898038540aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='queryArea']/div[2]/div/div[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>eedf723e-0942-4a32-815a-6aef1e8e69e5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Air Waybill 2</value>
      <webElementGuid>1f073777-4a6d-437c-bd1b-6edbbe203932</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;queryArea&quot;)/div[@class=&quot;row input-area&quot;]/div[@class=&quot;col-xs-12 col-sm-6&quot;]/div[@class=&quot;awb-row&quot;]/span[1]</value>
      <webElementGuid>2dfe8aa2-a63a-4b74-bedc-216d80459ee1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='queryArea']/div[2]/div/div[2]/span</value>
      <webElementGuid>5f699e75-365b-446c-9f7a-f59eff4adbc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[1]/following::span[3]</value>
      <webElementGuid>aac36b12-e838-499d-979d-73f3c2a14eec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Air Waybill 1'])[1]/following::span[4]</value>
      <webElementGuid>6ace2bf5-e709-4fb5-ba54-c50f62ca05b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[2]/preceding::span[1]</value>
      <webElementGuid>a40c10d1-2e49-4a8a-b830-3d62dd3d6712</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Air Waybill 3'])[1]/preceding::span[4]</value>
      <webElementGuid>e972c5dd-e209-4dfd-a144-8bfd7748addb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Air Waybill 2']/parent::*</value>
      <webElementGuid>bef43064-4df6-489a-9c8c-133116c02115</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/span</value>
      <webElementGuid>66781827-50e7-4f79-800f-425192e4eb24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Air Waybill 2' or . = 'Air Waybill 2')]</value>
      <webElementGuid>c53b0bd8-d258-47b0-9631-7c24f1c9730a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
