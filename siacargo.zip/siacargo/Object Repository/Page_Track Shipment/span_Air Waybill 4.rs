<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Air Waybill 4</name>
   <tag></tag>
   <elementGuidId>2b013bd6-60e0-465b-a742-ac5b6a3d4d8a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='queryArea']/div[2]/div/div[4]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.awb-row-4 > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>74f94792-8f3d-47f1-aac1-9f83054002a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Air Waybill 4</value>
      <webElementGuid>51bcfca0-9659-4e62-a58e-13e6d1571bf3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;queryArea&quot;)/div[@class=&quot;row input-area&quot;]/div[@class=&quot;col-xs-12 col-sm-6&quot;]/div[@class=&quot;awb-row-4&quot;]/span[1]</value>
      <webElementGuid>f1b03cb2-714b-4941-bede-fb72611970e2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='queryArea']/div[2]/div/div[4]/span</value>
      <webElementGuid>7dd0930d-6a15-4542-b223-c5e9019e1180</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[3]/following::span[3]</value>
      <webElementGuid>49164a27-cab7-4870-90bb-8212c1d9e4ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Air Waybill 3'])[1]/following::span[4]</value>
      <webElementGuid>8ce9c3d5-9d55-482f-8649-21d25f006940</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[4]/preceding::span[1]</value>
      <webElementGuid>4dc0fb47-d965-46b0-a09b-3486ce67d9ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Air Waybill 5'])[1]/preceding::span[4]</value>
      <webElementGuid>92036cae-b481-4203-a12b-11f0b2dbad59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Air Waybill 4']/parent::*</value>
      <webElementGuid>fa873213-e3a9-472d-85bb-ce5accc6f5fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/span</value>
      <webElementGuid>e38fee21-9be3-4195-81c8-f2cfcdac2d67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Air Waybill 4' or . = 'Air Waybill 4')]</value>
      <webElementGuid>dad91061-e753-47bb-b759-aae07972ba09</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
