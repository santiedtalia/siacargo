<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Track      Shipment</name>
   <tag></tag>
   <elementGuidId>f77d0e4a-0890-4e5b-b64f-a200d6f1d40d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@onclick=&quot;window.open('ccn/ShipmentTrack.aspx', '_blank')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.btn.btn-default</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>749f3373-4222-4adc-8a4f-677146ccc8bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default</value>
      <webElementGuid>d6c49d7f-9a05-48ff-8849-cf4a63ccb629</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>window.open('ccn/ShipmentTrack.aspx', '_blank')</value>
      <webElementGuid>28910e39-5ddb-4e5b-89c8-0215f55769b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 
      Track
      Shipment </value>
      <webElementGuid>ff83be21-2e99-4f99-9fed-8030ae458d33</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;body&quot;)/div[@class=&quot;container-fluid container index&quot;]/div[@class=&quot;hidden-xs col-xs-12 container list-bar no-padding&quot;]/div[@class=&quot;list-bar-btm&quot;]/button[@class=&quot;btn btn-default&quot;]</value>
      <webElementGuid>4eaa62a7-0e12-4f34-8f20-e4ec08b2171f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@onclick=&quot;window.open('ccn/ShipmentTrack.aspx', '_blank')&quot;]</value>
      <webElementGuid>6ece11e8-204d-4f40-a6a5-218ec17f719b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='body']/div[4]/div[2]/div/button</value>
      <webElementGuid>75cd5bf7-ad36-4c12-8a82-239fa6033d6d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Network Map'])[1]/preceding::button[1]</value>
      <webElementGuid>aa3a745b-96b7-42fd-9fe2-e94e2e6c0fd6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/button</value>
      <webElementGuid>bfa0579d-e100-462a-a63f-dc68a9effcd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' 
      Track
      Shipment ' or . = ' 
      Track
      Shipment ')]</value>
      <webElementGuid>ece854a5-609b-4b97-b02c-b6ebf17b740e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
