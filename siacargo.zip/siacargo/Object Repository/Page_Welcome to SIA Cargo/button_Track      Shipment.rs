<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Track      Shipment</name>
   <tag></tag>
   <elementGuidId>36c9c9b7-09db-49a5-8d05-f7d423cb69ef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@onclick=&quot;window.open('ccn/ShipmentTrack.aspx', '_blank')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.btn.btn-default</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>122c7bb7-18ba-42de-80f4-ccb4ad099e8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default</value>
      <webElementGuid>e214f80a-aff4-46df-a7ba-6789c038147a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>window.open('ccn/ShipmentTrack.aspx', '_blank')</value>
      <webElementGuid>7e91d500-597f-4772-9ade-e1c8dfd06a4b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 
      Track
      Shipment </value>
      <webElementGuid>617e310d-de2e-477e-b31f-395db24a218e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;body&quot;)/div[@class=&quot;container-fluid container index&quot;]/div[@class=&quot;hidden-xs col-xs-12 container list-bar no-padding&quot;]/div[@class=&quot;list-bar-btm&quot;]/button[@class=&quot;btn btn-default&quot;]</value>
      <webElementGuid>ebdf5ab3-78c3-47cc-bd45-a52c6c5ffa88</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@onclick=&quot;window.open('ccn/ShipmentTrack.aspx', '_blank')&quot;]</value>
      <webElementGuid>d385c56c-ee3e-4846-9a7e-dd6303d48231</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='body']/div[4]/div[2]/div/button</value>
      <webElementGuid>5a220ce2-496b-4b07-a5fc-c91b66ca83e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Network Map'])[1]/preceding::button[1]</value>
      <webElementGuid>56e8706e-d992-41e8-beb6-d9a7b534d033</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/button</value>
      <webElementGuid>eb594ae0-f252-46f3-9cde-b5b67ec0b50a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' 
      Track
      Shipment ' or . = ' 
      Track
      Shipment ')]</value>
      <webElementGuid>6c43b1a0-ca3c-4b9b-8995-bac19005c645</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
