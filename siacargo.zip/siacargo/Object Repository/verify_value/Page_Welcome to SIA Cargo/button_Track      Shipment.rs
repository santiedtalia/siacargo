<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Track      Shipment</name>
   <tag></tag>
   <elementGuidId>16171f2f-3af1-4087-a314-1bccdeb07bb3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@onclick=&quot;window.open('ccn/ShipmentTrack.aspx', '_blank')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.btn.btn-default</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>d5552144-dd99-4593-85b8-93e19df40951</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default</value>
      <webElementGuid>57608f39-1e51-403a-96e2-7cff9b6889d0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>window.open('ccn/ShipmentTrack.aspx', '_blank')</value>
      <webElementGuid>195fad04-ffd7-4bf0-a66f-a7b19504f703</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 
      Track
      Shipment </value>
      <webElementGuid>35bae0ec-90b0-4884-8a57-f82e00b71175</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;body&quot;)/div[@class=&quot;container-fluid container index&quot;]/div[@class=&quot;hidden-xs col-xs-12 container list-bar no-padding&quot;]/div[@class=&quot;list-bar-btm&quot;]/button[@class=&quot;btn btn-default&quot;]</value>
      <webElementGuid>e2e14e1d-14dd-4f33-b84e-14e38e9c87cc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@onclick=&quot;window.open('ccn/ShipmentTrack.aspx', '_blank')&quot;]</value>
      <webElementGuid>631135fb-775c-4eff-a477-95b676ffef1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='body']/div[4]/div[2]/div/button</value>
      <webElementGuid>fb70a0f9-5dae-465c-8a40-e352f1f3b826</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Network Map'])[1]/preceding::button[1]</value>
      <webElementGuid>f7e49bc0-6a6c-42c3-8456-45454443d676</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/button</value>
      <webElementGuid>17bafeaa-f0f4-4b50-aab0-eac2552dc49a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' 
      Track
      Shipment ' or . = ' 
      Track
      Shipment ')]</value>
      <webElementGuid>bef27ce0-acd9-414d-be70-ae6ef032a268</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
